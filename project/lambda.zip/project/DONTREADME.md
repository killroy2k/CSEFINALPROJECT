Vynze's noobie github info stuff

When you wanna  

1. git fetch to grab the changes from repo
2. git log to see changes
3. git pull to update vscode




When you make changes in here(VScode)
1. git add .
2. git status
       to check if it is currently updated
3. git commit -m "Enter message here"
4. git push
5. doesnt work then git gud
