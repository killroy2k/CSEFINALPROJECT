
class EMAIL_INFO:
    # Protected Data Members
    _HOST_EMAIL = 'csefinalprojectusftest@gmail.com'
    _HOST_PASSWORD = 'uaac tzyt htwv nirc'           # Generate APP PW (KEY)
    _RECEIVER_EMAILS = ["csefinalprojectusftest@gmail.com"]

class API_KEYS:
    # Protected Data Members
    _NVD_KEY = 'bf1e1a0f-37b3-48df-a202-dfe0afc4361d'
    _OPENAI_KEY = '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'
    _TWITTER_KEY = 'AAAAAAAAAAAAAAAAAAAAAE1LqQEAAAAA3u7Ei9G49CrLHuclHPXAtrV9lE0%3DefaqrX23R89cDf4cvF9AwQSyOKqjCeyzslMhtu0kn7fTkFB6hX'